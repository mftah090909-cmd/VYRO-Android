# VYRO Android starter

This is the first native Android foundation for VYRO, built with Kotlin and Jetpack Compose.

## Current status
- Native Android project structure
- Custom VYRO dark visual identity
- Arabic-first UI with a simple AR/EN header toggle
- Bottom navigation: Home, Shorts, Rooms, Messages, Profile
- Demo feed and local like interaction
- Placeholder feature screens for future real backend integration
- GitHub Actions workflow to build a debug APK

## Important
This is a foundation/prototype, not yet a production social network.
Accounts, server-backed posts, uploads, realtime messaging, audio/video rooms,
streak synchronization, push notifications, moderation and payments are not
implemented yet. They require backend services, security rules, and testing.

## Build
The GitHub Actions workflow runs `gradle assembleDebug` on pushes to `main`
or manually through Actions > Build VYRO Android APK > Run workflow.
Download the `VYRO-debug-apk` artifact after a successful run.
