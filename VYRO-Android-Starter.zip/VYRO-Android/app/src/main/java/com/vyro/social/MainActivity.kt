package com.vyro.social

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF100F1B)
private val Panel = Color(0xFF1B1929)
private val Purple = Color(0xFF9A6BFF)
private val Cyan = Color(0xFF38D7D0)
private val Pink = Color(0xFFFF72B6)
private val Muted = Color(0xFFAAA6BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VyroApp() }
    }
}

private enum class Tab(val label: String) {
    Home("الرئيسية"), Shorts("شورتز"), Rooms("رومات"), Messages("الرسائل"), Profile("حسابي")
}

private data class DemoPost(val author: String, val handle: String, val time: String, val body: String, val likes: Int, val tag: String)

@Composable
private fun VyroApp() {
    var selected by remember { mutableStateOf(Tab.Home) }
    var english by remember { mutableStateOf(false) }
    var liked by remember { mutableStateOf(setOf<Int>()) }
    val posts = remember {
        listOf(
            DemoPost("ليان", "@layan", "قبل 8 دقائق", "أول يوم في VYRO ✨ خلونا نبنوا مجتمع مختلف!", 128, "مجتمع"),
            DemoPost("عمر", "@omar.fx", "قبل 25 دقيقة", "شن أكثر ميزة متحمسين لها؟ الرومات ولا الشورتز؟", 86, "نقاش"),
            DemoPost("VYRO Team", "@vyro", "قبل ساعة", "هنا تبدأ مساحتك. شارك أفكارك واكتشف ناس يشبهوك.", 240, "إعلان")
        )
    }
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Purple,
            secondary = Cyan, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("VYRO", fontSize = 27.sp, fontWeight = FontWeight.Black,
                            color = Purple, letterSpacing = 3.sp)
                        Text(if (english) "Your world. Your people." else "عالمك، ناسك، مساحتك",
                            color = Muted, fontSize = 11.sp)
                    }
                    IconButton(onClick = { english = !english }) {
                        Text(if (english) "AR" else "EN", color = Cyan, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { }) { Icon(Icons.Default.NotificationsNone, null, tint = Color.White) }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    Tab.values().forEach { tab ->
                        val icon = when (tab) {
                            Tab.Home -> Icons.Default.Home
                            Tab.Shorts -> Icons.Default.PlayCircle
                            Tab.Rooms -> Icons.Default.Groups
                            Tab.Messages -> Icons.Default.ChatBubble
                            Tab.Profile -> Icons.Default.Person
                        }
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Icon(icon, contentDescription = tab.name) },
                            label = { Text(if (english) tab.name else tab.label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan,
                                selectedTextColor = Cyan,
                                indicatorColor = Purple.copy(alpha = 0.18f),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (selected) {
                    Tab.Home -> HomeScreen(posts, liked, onLike = { index ->
                        liked = if (index in liked) liked - index else liked + index
                    })
                    Tab.Shorts -> FeatureScreen("VYRO SHORTS", "فيديوهات قصيرة عمودية", "هنا سنضيف مشغل فيديو رأسي، الإعجاب، التعليقات، والمشاركة.")
                    Tab.Rooms -> FeatureScreen("VYRO ROOMS", "رومات صوتية مباشرة", "هنا سنضيف إنشاء روم، الانضمام، المتحدثين، المشرفين والمحادثة.")
                    Tab.Messages -> FeatureScreen("VYRO MESSAGES", "محادثاتك في مكان واحد", "هنا سنضيف المحادثات الفردية والجماعية والرسائل الصوتية.")
                    Tab.Profile -> FeatureScreen("PROFILE", "ملفك الشخصي", "هنا سنضيف الصورة الشخصية، النبذة، المتابعين، والمنشورات.")
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(posts: List<DemoPost>, liked: Set<Int>, onLike: (Int) -> Unit) {
    var draft by remember { mutableStateOf("") }
    var showComposer by remember { mutableStateOf(false) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                listOf("أنت", "ليان", "عمر", "سارة", "Yousef").forEachIndexed { i, name ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(54.dp).background(
                                Brush.linearGradient(listOf(Purple, Cyan, Pink)), CircleShape
                            ).padding(2.dp).background(Panel, CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Text(if (i == 0) "+" else name.take(1), color = Color.White, fontWeight = FontWeight.Bold) }
                        Text(name, color = Muted, fontSize = 10.sp)
                    }
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).clickable { showComposer = true }.padding(15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.AddCircle, null, tint = Purple)
                Spacer(Modifier.width(10.dp))
                Text("شن في بالك؟ شارك منشور...", color = Muted, modifier = Modifier.weight(1f))
                Text("نشر", color = Cyan, fontWeight = FontWeight.Bold)
            }
        }
        if (showComposer) {
            item {
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp)) {
                    OutlinedTextField(value = draft, onValueChange = { draft = it }, label = { Text("اكتب منشورك") }, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showComposer = false }) { Text("إلغاء") }
                        Button(onClick = { showComposer = false; draft = "" }, enabled = draft.isNotBlank()) { Text("نشر تجريبي") }
                    }
                    Text("ملاحظة: النشر هنا تجريبي ومحلي إلى أن نربط قاعدة البيانات.", color = Muted, fontSize = 10.sp)
                }
            }
        }
        items(posts.indices.toList()) { index ->
            val post = posts[index]
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Purple, Cyan)), CircleShape), contentAlignment = Alignment.Center) {
                        Text(post.author.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(post.author, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${post.handle} • ${post.time}", color = Muted, fontSize = 10.sp)
                    }
                    Text(post.tag, color = Cyan, fontSize = 10.sp)
                    IconButton(onClick = {}) { Icon(Icons.Default.MoreHoriz, null, tint = Muted) }
                }
                Spacer(Modifier.height(14.dp))
                Text(post.body, color = Color.White, fontSize = 15.sp, lineHeight = 23.sp)
                Spacer(Modifier.height(14.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.07f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { onLike(index) }) {
                        Icon(if (index in liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            null, tint = if (index in liked) Pink else Muted)
                        Spacer(Modifier.width(5.dp))
                        Text("${post.likes + if (index in liked) 1 else 0}", color = Muted)
                    }
                    TextButton(onClick = {}) { Icon(Icons.Default.ChatBubbleOutline, null, tint = Muted); Text(" تعليق", color = Muted) }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = {}) { Icon(Icons.Default.Share, null, tint = Muted) }
                }
            }
        }
        item {
            Text("هذه نسخة تأسيسية ببيانات تجريبية. الحسابات والنشر الحقيقي والمحادثات ستُربط بالخادم في المرحلة التالية.",
                color = Muted, fontSize = 11.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun FeatureScreen(title: String, subtitle: String, description: String) {
    Column(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(104.dp).background(Brush.linearGradient(listOf(Purple, Cyan, Pink)), RoundedCornerShape(30.dp)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(48.dp)) }
        Spacer(Modifier.height(24.dp))
        Text(title, color = Purple, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(description, color = Muted, fontSize = 14.sp, lineHeight = 22.sp)
        Spacer(Modifier.height(20.dp))
        Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
            Text("قيد التطوير • Coming soon", color = Cyan, modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp))
        }
    }
}
